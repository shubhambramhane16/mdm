<?php $__env->startSection($json['module'], 'active menu-item-open'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-custom">
        <div class="card-header flex-wrap border-0 pt-3 pb-0">
            <div class="card-title">
                <h3 class="card-label"><?php echo e(ucfirst($json['module'])); ?> List
                </h3>
            </div>
            <form action="" method="get" class="w-100">
                <div class="row col-lg-12 pl-0 pr-0">
                    <div class="col-sm-3">
                        <div class="dataTables_length">
                            <label>Status</label>
                            <select name="status" value="" class="form-control">
                                <option value="">All Status</option>
                                <option value="0"
                                    <?php if(request('status') == '0'): ?> <?php echo e(runTimeSelection(0, request('status'))); ?> <?php endif; ?>>
                                    InActive</option>
                                <option value="1"
                                    <?php if(request('status') == '1'): ?> <?php echo e(runTimeSelection(1, request('status'))); ?> <?php endif; ?>>
                                    Active</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-5">
                        <div class="dataTables_length">
                            <label cla>&#160; </label>
                            <button type="submit" class="btn btn-success mt-7" data-toggle="tooltip"
                                title="Apply Filter">Filter</button>
                            <a href="<?php echo e(url('/admin/' . $json['module'] . '/list')); ?>" class="btn btn-default mt-7"
                                data-toggle="tooltip" title="Reset Filter">Reset</a>

                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-body">
            <!--begin: Datatable-->
            <table class="table table-bordered table-hover" id="myTable">
                <thead>
                    <tr>
                        <th class="custom_sno">SNo.</th>
                        <?php
                            $moduleName = $json['module'] ?? 'default';
                        ?>
                        <?php $__currentLoopData = $json['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <th>
                            <?php
                                $translationKey = $moduleName . '/view_list.fields.' . $field['label'];
                            ?>
                            <?php if(Lang::has($translationKey)): ?>
                                <label><?php echo e(__($translationKey)); ?></label>
                            <?php else: ?>
                                <label><?php echo e($field['label']); ?></label>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </th>
                        <th class="custom_status">Status</th>
                        <th class="custom_action">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($details) > 0): ?>
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <?php $__currentLoopData = $json['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($field['relation']) && $field['relation'] != ''): ?>
                                        <?php
                                            $relationData = $value->{$field['relation']}()->first();
                                        ?>
                                        <td>
                                            <?php if($relationData): ?>
                                                <?php echo e($relationData->{$field['config']['name']} ?? 'N/A'); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                    <?php else: ?>
                                        <td><?php echo e($value[$field['fieldKey']]); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <a href="javascript:void(0)"
                                        data-url="<?php echo e(url('/admin/' . $json['module'] . '/update-status/' . $value->id . '/' . $value->status)); ?>"
                                        onclick="changeStatus(this)"> <span
                                            class="label label-lg font-weight-bold label-light-<?php echo e($value->status == 1 ? 'success' : 'danger'); ?> label-inline"><?php echo e($value->status == 1 ? 'Active' : 'InActive'); ?></span></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('/admin/' . $json['module'] . '/edit/' . $value->id)); ?>"
                                        class="btn btn-sm btn-clean btn-icon" title="Edit details" data-toggle="tooltip">
                                        <i class="la la-edit"></i>
                                    </a>
                                    <a href="<?php echo e(url('/admin/' . $json['module'] . '/delete/' . $value->id)); ?>"
                                        class="btn btn-sm btn-clean btn-icon" title="Delete details" data-toggle="tooltip"
                                        onclick="return confirm('Are you sure you want to delete this item?');">
                                        <i class="la la-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </tbody>
            </table>
            <!--end: Datatable-->
        </div>
    </div>


    <script>
        function changeStatus() {
            confirm("Do you want to change status?");
        }
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <!-- <link href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" /> -->
    <link href="<?php echo e(asset('plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
            $('.dataTables_filter label input[type=search]').addClass('form-control form-control-sm');
            $('.dataTables_length select').addClass('custom-select custom-select-sm form-control form-control-sm');
        });
    </script>
    
    <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <!-- <script src="<?php echo e(asset('plugins/custom/datatables/datatables.bundle.js')); ?>" type="text/javascript"></script> -->

    
    <!-- <script src="<?php echo e(asset('js/pages/crud/datatables/basic/basic.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\vv project\resources\views/admin/layout/data-view-master/list.blade.php ENDPATH**/ ?>