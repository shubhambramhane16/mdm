<?php $__env->startSection('content'); ?>

    <!--begin::Main-->
    <div class=" vh-100">
        <div class="row h-100 m-0">
            <!-- Left Side - Welcome Section -->
            <div class="col-md-6 welcome-section text-center text-white d-flex flex-column justify-content-center">
                <h1>Welcome to <?php echo e(config('app.name')); ?></h1>
                
                
                <p class="profile-para">

                    An Exclusive and Automated One Stop Portal For All Your Sales and Order Management!.</p>
            </div>

            <!-- Right Side - Login Section -->
            <div class="col-md-6 d-flex flex-column justify-content-center align-items-center login-section">
                <div class="login-container p-4 rounded">
                    <div class="text-center mb-4">
                        <img src="<?php echo e(asset('media/logos/Master.png')); ?>" alt="Logo" class="img-fluid">
                    </div>

                    
                    <form class="form" novalidate="novalidate" id="kt_login_signin_form" action="<?php echo e(url('admin/auth/login')); ?>" method="post">
                         <?php echo e(csrf_field()); ?>


                         <div class="form-group">
                             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <div class="alert alert-danger" role="alert">
                                 <strong><?php echo e($message); ?></strong>
                             </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <div class="alert alert-danger" role="alert">
                                 <strong><?php echo e($message); ?></strong>
                             </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <div class="alert alert-danger" role="alert">
                                 <strong><?php echo e($message); ?></strong>
                             </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             <?php if(request('error')): ?>
                             <div class="alert alert-danger" role="alert">
                                 <strong><?php echo e(request('error')); ?></strong>
                             </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                         <div class="form-group col-md-12">
                             <label class="font-size-h6 font-weight-bolder text-dark">Email</label>
                             <input class="form-control form-control-solid h-auto py-6 px-6 rounded-lg" type="text" name="email" autocomplete="off" isrequired="isrequired" />

                         </div>
                         <!--end::Form group-->
                         <!--begin::Form group-->
                         <div class="form-group col-md-12">
                             <div class="d-flex justify-content-between mt-n5">
                                 <label class="font-size-h6 font-weight-bolder text-dark pt-5">Password</label>

                             </div>
                             <input class="form-control form-control-solid h-auto py-6 px-6 rounded-lg" type="password" name="password" autocomplete="off" isrequired="isrequired" />

                         </div>
                         <!--end::Form group-->
                         <!--begin::Action-->
                         <div class="form-group col-md-12 center">
                             <button type="submit" id="kt_login_signin_submit" class="btn btn-primary font-weight-bolder font-size-h6 px-8 py-4 my-3 mr-3">Sign In</button>
                         </div>
                         <!--end::Action-->
                     </form>
                </div>
            </div>
        </div>
    </div>
    <!--end::Main-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <style>
        .welcome-section {
            background-color: #0e4c83 !important;
            /* Red background */
            padding: 50px;
            /* background-image: url(<?php echo e(asset('/media/custom/login-bg.png')); ?>); */
            /* Use a background image for effect */
            background-size: cover;
            background-repeat: no-repeat;
        }

        .welcome-section h1 {
            font-size: 48px;
            font-weight: bold;
        }

        .welcome-section p {
            font-size: 18px;
            margin-top: 20px;
            color: #fff;
        }

        .profile-para {
            font-size: 14px !important;
        }

        /* Login Section */
        .login-section {
            background-color: #f9f9f9;
            /* Light gray background */
        }

        .login-container {
            border-radius: 10px;
            padding: 30px;
            width: 100%;
        }

        .login-container img {
            max-width: 150px;
        }

        .input-group-text {
            background-color: transparent;
            border: none;
        }

        .input-group-text i {
            font-size: 24px;
            color: #0e4c83;
        }

        .btn-danger {
            background-color: #0e4c83;
            border-color: #0e4c83;
        }

        .btn-danger i {
            margin-left: 10px;
        }

        .submit-btn {
            width: 100%;
            display: flex;
            justify-content: center;
            margin: auto;
            align-items: center;
            text-align: center;
            margin-top: 4rem !important;

        }

        .submit-btn button {
            padding: 10px 40px;
            background-color: #0e4c83;
            color: #fff !important;

        }

        .submit-btn button a {
            color: #fff !important;

        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    

    <script src="<?php echo e(url('/')); ?>/js/custom.js" type="text/javascript"></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.pages.auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\Master-crm\resources\views/admin/pages/auth/login.blade.php ENDPATH**/ ?>