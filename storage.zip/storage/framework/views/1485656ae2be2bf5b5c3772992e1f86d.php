<?php $__env->startSection('dashboard','active menu-item-open'); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-custom">
    <div class="card-header flex-wrap border-0">
        <div class="card-title">
            <h3 class="card-label">Dashboard</h3>
        </div>
    </div>
    <div class="card-body">
        <p>Welcome to CRM</p>
    </div>
</div>
<?php $__env->stopSection(); ?>





<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\Master-crm\resources\views/admin/pages/dashboard/list.blade.php ENDPATH**/ ?>