<?php $__env->startSection('module','active menu-item-open'); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-custom">

    <div class="card-body">
        <div class="mb-7">
            <div class="row align-items-center">

                <form method="POST" action="" class="w-100">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-lg-9 col-xl-12">
                        <div class="row align-items-center">

                            <div class="form-group col-md-12">
                                <label>Parent Module</label>
                                <select class="form-control" name="parent_id" id="parent_id">
                                    <option value="">Select Parent Module</option>
                                    <?php if($modules = App\Models\Module::where('status', 1)->get()): ?>
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($module->id); ?>" <?php echo e(runTimeSelection(old('parent_id'),$module->id)); ?>><?php echo e($module->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Module Name</label>
                                <div><input type="text" name="name" value="<?php echo e(old('name')); ?>" isrequired="required" class="form-control" placeholder="Enter Module Name"></div>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Module Slug</label>
                                <div><input type="text" name="slug" value="<?php echo e(old('slug')); ?>" isrequired="required" class="form-control" placeholder="Enter Module Slug"></div>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Module Icon</label>
                                <div><input type="text" name="icon" value="<?php echo e(old('icon')); ?>" isrequired="required" class="form-control" placeholder="Enter Module Icon"></div>
                            </div>




                            <div class="form-group col-md-12">
                                <label>Module Description</label>
                                <div><textarea name="description" class="form-control" rows="20" cols="10" placeholder="Enter Module Description"><?php echo e(old('description')); ?></textarea></div>
                            </div>



                            <div class="form-group col-md-12">
                                <center><button class="btn btn-success">Submit</button></center>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#parent_id').select2({
            placeholder: "Select Parent Module",
            allowClear: true
        });
    });
    // name to slug conversion
    $(document).on('keyup', 'input[name="name"]', function() {
        var name = $(this).val();
        var slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
        $('input[name="slug"]').val(slug);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\vv project\resources\views/admin/pages/module/add.blade.php ENDPATH**/ ?>