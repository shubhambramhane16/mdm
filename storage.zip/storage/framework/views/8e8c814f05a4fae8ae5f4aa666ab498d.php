

<div class="footer bg-white py-4 d-flex flex-lg-column <?php echo e(Metronic::printClasses('footer', false)); ?>" id="kt_footer">
    
    <div class="<?php echo e(Metronic::printClasses('footer-container', false)); ?> d-flex flex-column flex-md-row align-items-center justify-content-between">
        
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted font-weight-bold mr-2">Copyright  &copy <?php echo e(date("Y")); ?> Avana . Designed & developed by </span>
          <a href="https://abym.in" target="_blank" class="text-dark-75 text-hover-primary">AbyM Technology.</a>
        </div>


    </di v>
</div>
<?php /**PATH D:\sumeshwar sir plans\Master-crm\resources\views/admin/layout/base/_footer.blade.php ENDPATH**/ ?>