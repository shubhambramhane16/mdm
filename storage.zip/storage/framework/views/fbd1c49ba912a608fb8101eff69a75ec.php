<?php if(config('layout.self.layout') == 'blank'): ?>
<div class="d-flex flex-column flex-root">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php else: ?>

<?php echo $__env->make('admin.layout.base._header-mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="d-flex flex-column flex-root">
    <div class="d-flex flex-row flex-column-fluid page">

        <?php if(config('layout.aside.self.display')): ?>
        <?php echo $__env->make('admin.layout.base._aside', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">

            <?php echo $__env->make('admin.layout.base._header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="content <?php echo e(Metronic::printClasses('content', false)); ?> d-flex flex-column flex-column-fluid" id="kt_content">
 

                <?php echo $__env->make('admin.layout.base._content', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <?php echo $__env->make('admin.layout.base._footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>

<?php endif; ?>
 <?php /**PATH D:\sumeshwar sir plans\vv project\resources\views/admin/layout/base/_layout.blade.php ENDPATH**/ ?>