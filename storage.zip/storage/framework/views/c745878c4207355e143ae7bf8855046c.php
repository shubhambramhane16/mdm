

<?php
    $kt_logo_image = 'Master_sidebar.png';
?>

<?php if(config('layout.brand.self.theme') === 'light'): ?>
    <?php $kt_logo_image = 'Master_sidebar.png' ?>
<?php elseif(config('layout.brand.self.theme') === 'dark'): ?>
    <?php $kt_logo_image = 'Master_sidebar.png' ?>
<?php endif; ?>

<div class="aside aside-left <?php echo e(Metronic::printClasses('aside', false)); ?> d-flex flex-column flex-row-auto"
    id="kt_aside">

    
    <div class="brand flex-column-auto <?php echo e(Metronic::printClasses('brand', false)); ?>" id="kt_brand">
        <div class="brand-logo text-center">
            <a href="<?php echo e(url('/')); ?>">

                <img class="pt-10  w-70" alt="<?php echo e(config('app.name')); ?>"
                    src="<?php echo e(asset('media/logos/' . $kt_logo_image)); ?>" />
            </a>
        </div>

        <?php if(config('layout.aside.self.minimize.toggle')): ?>
            <button class="brand-toggle btn btn-sm px-0" id="kt_aside_toggle">
                <?php echo e(Metronic::getSVG('media/svg/icons/Navigation/Angle-double-left.svg', 'svg-icon-xl')); ?>

            </button>
        <?php endif; ?>

    </div>

    
    <div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">

        

        <?php
            if (auth()->user()->role_id) {
                $role = getRoleById(auth()->user()->role_id);
                $existingPermissions = $role->permission ? json_decode($role->permission, true) : [];
            }
        ?>

        <div id="kt_aside_menu" class="aside-menu <?php echo e(Metronic::printClasses('aside_menu', false)); ?>"
            data-menu-vertical="1" <?php echo e(Metronic::printAttrs('aside_menu')); ?>>
            <ul class="menu-nav <?php echo e(Metronic::printClasses('aside_menu_nav', false)); ?>">
                <?php
                    // Example menu structure
                    $menu = modulesListNew();
                    $menu = collect($menu)
                        ->map(function ($item) {
                            return [
                                'label' => $item['module_name'],
                                'icon' => $item['icon'] ?? 'dashboard',
                                'route' => $item['route'] ?? '#',
                                'sortOrder' => $item['sortOrder'] ?? 0,
                                'id' => $item['id'] ?? '',
                                'children' => isset($item['children'])
                                    ? collect($item['children'])
                                        ->map(function ($child) {
                                            return [
                                                'label' => $child['module_name'],
                                                'icon' => $child['icon'] ?? 'dashboard',
                                                'route' => $child['route'] ?? '#',
                                                'sortOrder' => $child['sortOrder'] ?? 0,
                                                'id' => $child['id'] ?? '',
                                            ];
                                        })
                                        ->toArray()
                                    : [],
                            ];
                        })
                        ->toArray();
                    // Sort the menu items by sortOrder
                    $menu = collect($menu)->sortBy('sortOrder')->values()->toArray();
                ?>

                <?php $__currentLoopData = collect($menu)->sortBy('sortOrder'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $hasChildren =
                            isset($item['children']) && is_array($item['children']) && count($item['children']) > 0;
                    ?>
                    <li class="menu-item <?php echo $__env->yieldContent($item['id']); ?> <?php echo e($hasChildren ? 'menu-item-submenu' : ''); ?>"
                        aria-haspopup="true" <?php echo e($hasChildren ? 'data-menu-toggle=hover' : ''); ?>>
                        <a href="<?php echo e($hasChildren ? '#' : url('/admin/' . ltrim($item['route'], '/'))); ?>"
                            class="menu-link <?php echo e($hasChildren ? 'menu-toggle' : ''); ?>">
                            <span class="svg-icon menu-icon">
                                <?php if($item['icon'] === 'dashboard'): ?>
                                    
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        fill="none">
                                        <rect width="24" height="24" fill="none" />
                                        <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"
                                            fill="#000" />
                                    </svg>
                                <?php elseif($item['icon'] === 'users'): ?>
                                    
                                    <svg xmlns="http://www.w3.org/2000/svg" height="24" width="24"
                                        viewBox="0 0 640 512">
                                        <path
                                            d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z" />
                                    </svg>
                                <?php else: ?>
                                    
                                    <i class="menu-icon flaticon2-menu-1"></i>
                                <?php endif; ?>
                            </span>
                            <span class="menu-text"><?php echo e($item['label']); ?></span>
                            <?php if($hasChildren): ?>
                                <i class="menu-arrow"></i>
                            <?php endif; ?>
                        </a>
                        <?php if($hasChildren): ?>
                            <div class="menu-submenu" kt-hidden-height="320">
                                <span class="menu-arrow"></span>
                                <ul class="menu-subnav">
                                    <li class="menu-item menu-item-parent" aria-haspopup="true">
                                        <span class="menu-link"><span
                                                class="menu-text"><?php echo e($item['label']); ?></span></span>
                                    </li>
                                    <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="menu-item" aria-haspopup="true">
                                            <a href="<?php echo e(url('/admin/' . $child['route'])); ?>" class="menu-link">
                                                <i class="menu-bullet menu-bullet-line"><span></span></i>
                                                <span class="menu-text"><?php echo e($child['label']); ?></span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        </div>
    </div>

</div>
<?php /**PATH D:\sumeshwar sir plans\Master-crm\resources\views/admin/layout/base/_aside.blade.php ENDPATH**/ ?>