<?php $__env->startSection($json['module'], 'active menu-item-open'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-custom">
        <div class="card-body">
            <div class="mb-7">
                <div class="row align-items-center">
                    <div class="col-12">
                        <form method="POST" action="" class="w-100" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                
                                <?php
                                $moduleName = $json['module'] ?? 'default';
                                $json = $json['data'] ?? []; ?>
                                <?php $__currentLoopData = $json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $value['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldKey => $fieldValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $col = isset($fieldValue['column'])
                                                ? 'col-md-' . $fieldValue['column']
                                                : 'col-md-12';
                                            $validation = isset($fieldValue['validation'])
                                                ? $fieldValue['validation']
                                                : [];
                                            $isRequired =
                                                isset($validation['isRequired']) && $validation['isRequired']
                                                    ? 'isrequired="required"'
                                                    : '';
                                            $maxLength = isset($validation['maxLength'])
                                                ? 'maxlength=' . $validation['maxLength']
                                                : '';
                                            $readonly =
                                                isset($fieldValue['restrictions']['readonly']) &&
                                                $fieldValue['restrictions']['readonly']
                                                    ? 'readonly'
                                                    : '';


                                        ?>
                                        <div class="form-group <?php echo e($col); ?>">
                                            <?php if(empty($fieldValue['visibilityCondition'])): ?>
                                                <?php
                                                    $translationKey = $moduleName . '/add_form.form.' . ($fieldValue['label'] ?? $fieldValue['fieldKey'] ?? $fieldKey);
                                                ?>
                                                <?php if(Lang::has($translationKey)): ?>
                                                    <label><?php echo e(__($translationKey)); ?></label>
                                                <?php else: ?>
                                                    <label><?php echo e($fieldValue['label']); ?></label>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php switch($fieldValue['type']):
                                                case ('text'): ?>

                                                    <input type="text" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?> <?php echo e($readonly); ?>

                                                        <?php if(!empty($fieldValue['tooltip'])): ?> title="<?php echo e($fieldValue['tooltip']); ?>" <?php endif; ?>
                                                        <?php if(isset($fieldValue['validation']['maxLength'])): ?> max="<?php echo e($fieldValue['validation']['maxLength']); ?>" <?php endif; ?>
                                                        <?php if(isset($fieldValue['validation']['minLength'])): ?> min="<?php echo e($fieldValue['validation']['minLength']); ?>" <?php endif; ?>>

                                                <?php break; ?>

                                                <?php case ('email'): ?>
                                                    <input type="email" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>>
                                                <?php break; ?>

                                                <?php case ('password'): ?>
                                                    <input type="password" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>>
                                                <?php break; ?>

                                                <?php case ('number'): ?>
                                                    <input type="number" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>>
                                                <?php break; ?>

                                                <?php case ('date'): ?>
                                                    <input type="date" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>>
                                                <?php break; ?>

                                                <?php case ('datetime'): ?>
                                                    <input type="datetime-local" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control" placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>"
                                                        <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>>
                                                <?php break; ?>

                                                <?php case ('textarea'): ?>
                                                    <textarea name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>" class="form-control"
                                                        placeholder="<?php echo e($fieldValue['placeholder'] ?? ''); ?>" <?php echo e($isRequired); ?> <?php echo e($maxLength); ?>></textarea>
                                                <?php break; ?>

                                                <?php case ('file'): ?>
                                                    <input type="file" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                        class="form-control-file" <?php echo e($isRequired); ?>

                                                        <?php if(isset($validation['allowedTypes'])): ?> accept="<?php echo e(implode(',', array_map(fn($ext) => '.' . $ext, $validation['allowedTypes']))); ?>" <?php endif; ?>>
                                                    <?php if(isset($validation['maxSizeMb'])): ?>
                                                        <small class="form-text text-muted">
                                                            Max file size: <?php echo e($validation['maxSizeMb']); ?>MB.
                                                        </small>
                                                    <?php endif; ?>
                                                <?php break; ?>

                                                <?php case ('radio'): ?>
                                                    <?php $__currentLoopData = $fieldValue['dataSourceValue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-check">
                                                            <input type="radio" name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                                class="form-check-input"
                                                                id="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey . '_' . $option); ?>"
                                                                value="<?php echo e($option); ?>">
                                                            <label class="form-check-label"
                                                                for="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey . '_' . $option); ?>"><?php echo e($option); ?></label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php break; ?>

                                                <?php case ('dropdown'): ?>
                                                    <?php if($fieldValue['dataSourceType'] == 'static'): ?>
                                                        <select name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                            class="form-control select" <?php echo e($isRequired); ?>>
                                                            <?php $__currentLoopData = $fieldValue['dataSourceValue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                    <?php elseif($fieldValue['dataSourceType'] == 'master'): ?>
                                                        <?php
                                                            $dataSource = $fieldValue['dataSource'] ?? [];
                                                        ?>

                                                        <?php if($dataSource): ?>
                                                            <?php $moduleName = ucfirst($dataSource); ?>

                                                            <?php
                                                                $modelClass = 'App\\Models\\' . $moduleName;
                                                                if (!empty($fieldValue['condition'])) {
                                                                    $options = app($modelClass)
                                                                        ::where(
                                                                            $fieldValue['condition']['fieldKey'],$fieldValue['condition']['operator'],
                                                                            $fieldValue['condition']['value'],
                                                                        )
                                                                        ->get();
                                                                } else {
                                                                    $options = app($modelClass)::all();
                                                                }
                                                            ?>

                                                            <select name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>"
                                                                class="form-control select"
                                                                id="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>" <?php echo e($isRequired); ?>>
                                                                <option value="">Select <?php echo e($moduleName); ?></option>
                                                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($detail['id']); ?>"><?php echo e($detail['name']); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php break; ?>

                                                <?php case ('repeater'): ?>
                                                    <div class="repeater">
                                                        <div class="">
                                                            <div class="row"
                                                                data-item-id="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>-items">
                                                                <div class="col-md-10 repeater-items"
                                                                    data-item-id="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>-items">
                                                                    <?php for($i = 0; $i < ($fieldValue['defaultItems'] ?? 1); $i++): ?>
                                                                        <div class="repeater-item row align-items-end">
                                                                            <?php $__currentLoopData = $fieldValue['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php
                                                                                    $subCol = isset($subField['column'])
                                                                                        ? 'col-md-' .
                                                                                            $subField['column']
                                                                                        : 'col-md-12';
                                                                                    $subValidation = isset(
                                                                                        $subField['validation'],
                                                                                    )
                                                                                        ? $subField['validation']
                                                                                        : [];
                                                                                    $subIsRequired =
                                                                                        isset(
                                                                                            $subValidation[
                                                                                                'isRequired'
                                                                                            ],
                                                                                        ) &&
                                                                                        $subValidation['isRequired']
                                                                                            ? 'required'
                                                                                            : '';
                                                                                    $subMaxLength = isset(
                                                                                        $subValidation['maxLength'],
                                                                                    )
                                                                                        ? 'maxlength=' .
                                                                                            $subValidation['maxLength']
                                                                                        : '';
                                                                                    $subMinLength = isset(
                                                                                        $subValidation['minLength'],
                                                                                    )
                                                                                        ? 'minlength=' .
                                                                                            $subValidation['minLength']
                                                                                        : '';
                                                                                    $subMin = isset(
                                                                                        $subValidation['min'],
                                                                                    )
                                                                                        ? 'min=' . $subValidation['min']
                                                                                        : '';
                                                                                    $subMax = isset(
                                                                                        $subValidation['max'],
                                                                                    )
                                                                                        ? 'max=' . $subValidation['max']
                                                                                        : '';
                                                                                ?>
                                                                                <div class="form-group <?php echo e($subCol); ?>">
                                                                                    <label><?php echo e($subField['label']); ?></label>
                                                                                    <?php switch($subField['type']):
                                                                                        case ('text'): ?>
                                                                                        <?php case ('email'): ?>

                                                                                        <?php case ('number'): ?>
                                                                                        <?php case ('date'): ?>

                                                                                        <?php case ('datetime-local'): ?>
                                                                                            <input type="<?php echo e($subField['type']); ?>"
                                                                                                name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>[<?php echo e($i); ?>][<?php echo e($subField['fieldKey']); ?>]"
                                                                                                class="form-control"
                                                                                                placeholder="<?php echo e($subField['placeholder'] ?? ''); ?>"
                                                                                                <?php echo e($subIsRequired); ?> <?php echo e($subMaxLength); ?>

                                                                                                <?php echo e($subMinLength); ?> <?php echo e($subMin); ?>

                                                                                                <?php echo e($subMax); ?>>
                                                                                        <?php break; ?>

                                                                                        <?php case ('textarea'): ?>
                                                                                            <textarea name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>[<?php echo e($i); ?>][<?php echo e($subField['fieldKey']); ?>]"
                                                                                                class="form-control" placeholder="<?php echo e($subField['placeholder'] ?? ''); ?>" <?php echo e($subIsRequired); ?> <?php echo e($subMaxLength); ?>

                                                                                                <?php echo e($subMinLength); ?>></textarea>
                                                                                        <?php break; ?>

                                                                                        <?php default: ?>
                                                                                            <input type="text"
                                                                                                name="<?php echo e($fieldValue['fieldKey'] ?? $fieldKey); ?>[<?php echo e($i); ?>][<?php echo e($subField['fieldKey']); ?>]"
                                                                                                class="form-control"
                                                                                                placeholder="<?php echo e($subField['placeholder'] ?? ''); ?>"
                                                                                                <?php echo e($subIsRequired); ?> <?php echo e($subMaxLength); ?>

                                                                                                <?php echo e($subMinLength); ?> <?php echo e($subMin); ?>

                                                                                                <?php echo e($subMax); ?>>
                                                                                    <?php endswitch; ?>
                                                                                </div>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    <?php endfor; ?>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <button type="button"
                                                                        class="btn btn-primary add-repeater-item mt-8"
                                                                        type="button">+</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php break; ?>
                                            <?php endswitch; ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group col-md-<?php echo e($value['gridColumns'] ?? '12'); ?>">
                                        <center><button class="btn btn-success"><?php echo e(__($moduleName . '/add_form.actions.submit')); ?></button></center>
                                        </center>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <style>
        textarea.form-control {
            height: 250px !important;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select').select2({
                placeholder: "Select an option",
                allowClear: true
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Handle add repeater item button click
            $(document).on('click', '.add-repeater-item', function() {
                var $repeater = $(this).closest('.repeater');
                var $itemsContainer = $repeater.find('.repeater-items');
                var $firstItem = $itemsContainer.children('.repeater-item:first');
                var $newItem = $firstItem.clone();

                // Determine new index for the repeater item
                var newIndex = $itemsContainer.children('.repeater-item').length;

                // Clear input/textarea values and update names/ids in the cloned item
                $newItem.find('input, textarea').each(function() {
                    $(this).val('');
                    // Update name attribute index
                    var name = $(this).attr('name');
                    if (name) {
                        name = name.replace(/\[\d+\]/, '[' + newIndex + ']');
                        $(this).attr('name', name);
                    }
                    // Update id attribute index if present
                    var id = $(this).attr('id');
                    if (id) {
                        id = id.replace(/_\d+$/, '_' + newIndex);
                        $(this).attr('id', id);
                    }
                });

                // Remove any existing remove button to avoid duplicates
                $newItem.find('.remove-repeater-item').closest('.col-12').remove();

                // Add remove button
                $newItem.append(
                    '<div class="col-12 mt-2"><button type="button" class="btn btn-danger remove-repeater-item">Remove</button></div>'
                );

                $itemsContainer.append($newItem);
            });

            // Handle remove repeater item button click
            $(document).on('click', '.remove-repeater-item', function() {
                var $item = $(this).closest('.repeater-item');
                var $itemsContainer = $item.parent();
                $item.remove();

                // Re-index the remaining repeater items
                $itemsContainer.children('.repeater-item').each(function(index) {
                    $(this).find('input, textarea').each(function() {
                        var name = $(this).attr('name');
                        if (name) {
                            name = name.replace(/\[\d+\]/, '[' + index + ']');
                            $(this).attr('name', name);
                        }
                        var id = $(this).attr('id');
                        if (id) {
                            id = id.replace(/_\d+$/, '_' + index);
                            $(this).attr('id', id);
                        }
                    });
                });
            });
        });
    </script>

    <script>
        // create module slug on click of module title
        $(document).on('change', 'input[name="name"]', function() {
            var moduleTitle = $(this).val();
            var slug = moduleTitle.toLowerCase().replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '');
            $('input[name="slug"]').val(slug);
        });
    </script>
    <script>
        // get the subcategory based on parent category
        $(document).on('change', 'select[id="category_id"]', function() {
            var parentId = $(this).val();
            var subCategorySelect = $('select[id="subcategory_id"]');
            subCategorySelect.empty();
            subCategorySelect.append('<option value="">Select Sub Category</option>');
            if (parentId) {
            $.ajax({
                url: '<?php echo e(url("/admin/subcategory-list")); ?>',
                type: 'GET',
                data: {
                category_id: parentId
                },
                success: function(data) {
                subCategorySelect.empty();
                if (data && Array.isArray(data) && data.length > 0) {
                    $.each(data, function(index, subCategory) {
                    subCategorySelect.append(
                        '<option value="' + subCategory.id + '">' + subCategory.name + '</option>'
                    );
                    });
                } else {
                    subCategorySelect.append('<option value="">No Sub Categories Found</option>');
                }
                },
                error: function(xhr, status, error) {
                subCategorySelect.empty();
                subCategorySelect.append('<option value="">Error fetching subcategories</option>');
                }
            });
            } else {
            subCategorySelect.append('<option value="">Select Sub Category</option>');
            }
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\vv project\resources\views/admin/layout/form-master/add.blade.php ENDPATH**/ ?>