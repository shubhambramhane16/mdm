<?php $__env->startSection('user','active menu-item-open'); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-custom">

    <div class="card-body">
        <div class="mb-7">
            <div class="row align-items-center">

                <form method="POST" action="" class="w-100">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-lg-9 col-xl-12">
                        <div class="row align-items-center">
                            <div class="form-group col-md-6">
                                <label>Name</label>
                                <div><input type="text" name="name" value="<?php echo e($details->name); ?>" isrequired="required" class="form-control" placeholder="Enter User Name"></div>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Email/User Name </label>
                                <div><input type="email" name="email" value="<?php echo e($details->email); ?>" isrequired="required" class="form-control" placeholder="Enter Email"></div>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Mobile No.</label>
                                <div><input type="text" name="mobile" value="<?php echo e($details->mobile); ?>" isrequired="required" class="form-control number" placeholder="Enter Mobile Number"></div>
                            </div>
                            <!-- <div class="form-group col-md-6">
                                <label>Password </label>
                                <div><input type="password" name="password" value="<?php echo e($details->password); ?>" isrequired="required" class="form-control" placeholder="Enter Password"></div>
                            </div> -->
                            <div class="form-group col-md-6">
                                <label>Password </label>
                                <div>
                                    <button type="button" class="btn btn-primary " data-toggle="modal"
                                        data-target="#password-change">Change Password
                                    </button>
                                </div>

                            </div>
                            <div class="form-group col-md-6">
                                <label>User Role</label>

                                <select class="form-control" name="role_id" id="role_id" isrequired="required">
                                    <option value="">Select Role</option>
                                    <?php if($roles = getSystemRoles()): ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>" <?php echo e(runTimeSelection($details->role_id,$role->id)); ?>><?php echo e($role->role); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-12">
                                <center><button class="btn btn-success">Update</button></center>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\sumeshwar sir plans\Master-crm\resources\views/admin/pages/users/edit.blade.php ENDPATH**/ ?>